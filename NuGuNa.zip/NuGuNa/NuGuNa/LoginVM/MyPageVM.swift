//
//  MyPageVM.swift
//  NuGuNa
//
//  Created by 시모니 on 1/31/24.
//

import Foundation

class MyPageVM {
    
    let logOutURL = "http://3.34.164.96:8000/accounts/logout"
   
    
}
