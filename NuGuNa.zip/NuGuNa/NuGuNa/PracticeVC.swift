//
//  PracticeVC.swift
//  NuGuNa
//
//  Created by 시모니 on 2/6/24.
//

import UIKit

class PracticeVC: UIViewController {
    
    var data = [""]
    
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var textView: UITextView!
    
    
    @IBOutlet weak var button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        

       
    }
    
    @IBAction func tapBtn(_ sender: UIButton) {
        guard let text = self.textView.text else {return}
        let strData = text
        self.data.append(strData)
        self.tableView.reloadData()
        //텍스트필드안에 내용 다 지워야지
        self.textView.text = nil
        
        // 등록버튼 누르면 바로 최신데이터가 보일수있게 스크롤해줌
        let indexPath = IndexPath(row: self.data.count - 1, section: 0)
           self.tableView.scrollToRow(at: indexPath, at: .bottom, animated: true)
    }
    

}

extension PracticeVC: UITableViewDelegate , UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell") as? MyCell else {
            return UITableViewCell()
        }
        let myData = data[indexPath.row]
           cell.myLabel.text = myData
           
           // 짝수 번째 셀인지 확인하여 레이아웃을 조정합니다.
           if indexPath.row % 2 == 0 {
               // 짝수 번째 셀: 셀을 왼쪽에 붙이고 오른쪽 마진을 추가합니다.
               cell.myLabel.textAlignment = .left
               cell.contentView.layoutMargins = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 8)
           } else {
               // 홀수 번째 셀: 셀을 오른쪽에 붙이고 왼쪽 마진을 추가합니다.
               cell.myLabel.textAlignment = .right
               cell.contentView.layoutMargins = UIEdgeInsets(top: 0, left: 8, bottom: 0, right: 16)
           }
           
           return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
    
}

class MyCell: UITableViewCell {
    @IBOutlet weak var myLabel: UILabel!
}
