//
//  ApplyPopUpVM.swift
//  NuGuNa
//
//  Created by 시모니 on 2/6/24.
//

import Foundation

class ApplyPopUpVM {
    
    let applyURL = "http://3.34.164.96:8000/petitions/detail?BILL_NO="
}
