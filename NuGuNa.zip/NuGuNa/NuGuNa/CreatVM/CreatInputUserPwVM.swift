//
//  CreatInputUserPwVM.swift
//  NuGuNa
//
//  Created by 시모니 on 1/31/24.
//

import Foundation

class CreatInputUserPwVM {
    
    let signUpURL = "http://3.34.164.96:8000/accounts/signup"
    var pw1: String = ""
    var pw2: String = ""
    
}
