//
//  CreatUserNameVM.swift
//  NuGuNa
//
//  Created by 시모니 on 1/31/24.
//

import Foundation


class CreatInputUserNameVM {
    
    var name: String = "" 
    
}
